#!/bin/bash

#portrain (right)
sleep 10
xrandr -o left

for id in `xinput --list|grep 'eGalax\|ILITEK'|perl -ne 'while (m/id=(\d+)/g){print "$1\n";}'`; do
     #right
     #xinput set-prop $id --type=float "Coordinate Transformation Matrix" 0 1 0 -1 0 1 0 0 1
     #echo "xinput set-prop ${id} --type=float 'Coordinate Transformation Matrix' 0 1 0 -1 0 1 0 0 >

     #left
     xinput set-prop $id --type=float "Coordinate Transformation Matrix" 0 -1 1 1 0 0 0 0 1
     echo "xinput set-prop ${id} --type=float 'Coordinate Transformation Matrix' 0 -1 1 1 0 0 0 0 1"
done
